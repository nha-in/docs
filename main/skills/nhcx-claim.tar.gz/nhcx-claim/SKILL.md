---
name: nhcx-claim
description: Add the NHCX claim to a hospital information system or a standalone claims desk. Record the discharge (normal, LAMA, DAMA or death, with the surgery stage), file the claim (15) under the pre-auth's number, answer a claim query (161 on PMJAY) and read every answer (25, 26, 27, 291), held to the pinned bundles, including the LAMA collapse and the death rules. Starts by checking whether the app already files claims or records the discharge facts a claim needs, and whether the approved pre-auth it depends on exists, then builds, extends or reuses only what is missing. Self-contained; needs no other skill installed. Use for filing a claim, discharge variants, claim query answers, NHCX use cases B5, D9 and D10, flow steps F10 and F11.
---

# NHCX claim: the discharge and the final bill

This skill takes an approved pre-authorisation to a decided claim. It records the discharge with its mode and stage, files the claim under the pre-auth's number with the payer's reference, answers a PMJAY claim query in-band, and reads the acknowledgement and the decision.

Read `core/LADDER.md` first. It holds the ladder every NHCX skill walks: the definition of compliant, the stages, the workspace, how to run a stage, and the rules. This folder carries everything it needs and runs on its own; the other six NHCX skills are separate folders, and none of them has to be installed. Paths starting `core/`, `stages/`, `references/`, `fhir/`, `flow/`, `ui/`, `templates/` or `scripts/` are relative to this folder. Paths starting `nhcx-package/` are in the NHCX package, which `scripts/fetch-package.sh` fetches into the target project beside `nhcx-build/`; `references/material.md` names the package file of every pin by its label.

## What this skill covers

| | |
| --- | --- |
| Flow steps | F10 Record the discharge; F11 File the claim, and its query answer for a `resubmit` payer |
| Tabs | Claim (tab 7): the discharge card, documents for the claim, forms for the claim, everything attached for the claim, submit, the decision card |
| Wire | `v1/claim/submit`, `use claim`, workflow 15; 161 (PMJAY) or 151 (generic) for a query answer; 16 (generic only) to resubmit after a rejection. Answers: 25, then 26, 27 or 291 |
| Next actions | "Record the discharge", "File the claim", "Answer the claim query" (a `resubmit` payer), "Send the claim again" |
| Use cases | B5; D9 with its variants (normal; LAMA and DAMA before, during and after surgery; death); D10 |
| Modules | 7.7, the claim legs (15, 161, 151, 16); 7.8, the claim answers |
| Pins | `claim/request`, `claim/queryupdate`: `nhcx-package/fhir/B5/claim-{request,queryupdate}.json` |
| Payer fixtures | `nhcx-package/fhir/C7/*` (25, 26, 27, 291, generic and PMJAY); the live PMJAY shapes in `nhcx-package/fhir/D9` and `D10` |
| Tables | `claim_submission`: the claim leg and the discharge (mode, stage, discharged, surgery and death times) |
| FHIR | `fhir/FHIR.md` sections 4 (the claim leg, the LAMA collapse) and 5; `references/fhir-knowledge.md` sections 5 and 6 |

Not here: the reprocess, release and status cards on the Claim tab (the reprocess use case, `nhcx-reprocess`); a `communication` payer's claim query (the communication use case, `nhcx-communication`).

## Needs and hands on

Needs: an approved or partial pre-auth with `preauth_ref` and `claim_ref`, the dossier and the Claim bundle builder (the pre-auth use case); the lines (the insurance use case). Stage 0 checks for them below, whichever way the app got them.

Hands on: a filed claim with `claim_ref` and a decision: approved (with amounts and item verdicts, `deductible` included), rejected, partial or queried. Payment notices are matched against the claim number; a rejected or partial claim can be reprocessed.

## Capability check

Stage 0 (`stages/0-capability-check.md`) gives every capability below a verdict: search for the markers, run the check, record what was observed.

### Own

| Id | What | Look for | Present when (observed) |
| --- | --- | --- | --- |
| `claim.discharge` | F10: mode (normal, LAMA, DAMA, death), stage (before, during, after surgery), discharge, surgery and death times | a discharge mode on the encounter or the claim leg; `lama`, `dama`, `death`, `expired` | A discharge records each mode; a death needs its time; LAMA and DAMA need a stage; recording is refused unless a pre-auth is approved or partial |
| `claim.claim-bundle` | 7.7's builder, extended with the claim legs | `"use": "claim"`, `LM100`, `DSDE`, `DTM`, `HDS`, `DIS`, `preAuthRef` | The `claim/request` and `claim/queryupdate` pins pass; `Claim.id` equals the pre-auth's claim number and `insurance[0].preAuthRef` is the payer's; a death claim carries `ONS/DTM`; LAMA or DAMA before or during surgery carries one `LM100` item and nothing else; after the extension, the three pre-auth Claim pins still pass |
| `claim.send` | F11: `submit_claim` and the choice of send kind | `v1/claim/submit`, workflow ids `15`, `161`, `151`, `16` | With the 7.1 stub: 15 first; 161 on a PMJAY query and 151 on a generic one; 16 after a generic rejection and never on PMJAY; refused before any HTTP call without an approved pre-auth, without a recorded discharge or the discharge summary, or with an amount above the approved amount |
| `claim.response-reader` | 7.8 on the claim thread | `verdict_status`, workflow ids `25`, `26`, `27`, `291` | `submitting` on the 25, `approved` on the 26, `queried` on the 27, `rejected` on the 291; item verdicts keep `deductible` and the payer's reasons verbatim |
| `claim.query-answer` | F11 continued, a `resubmit` payer: 161 | `queryupdate`, `CQD` on the claim leg | The `claim/queryupdate` pin passes; the answer goes on a new correlation id; an empty reply is refused before sending |
| `claim.screens` | The Claim tab | the discharge card, the claim card | The claim card opens only after a discharge; for LAMA or DAMA before or during surgery it says the approved packages are voided and the claim will carry `LM100` only; the decision card renders from the stored answer |

### Foundation

All six capabilities in `core/FOUNDATION.md`. `foundation.storage` is partial until `claim_submission` holds the discharge columns; `foundation.state` until `case_stage` has the `claim` branch and `next_actions` the labels above.

### Prerequisites

The pre-auth use case (`nhcx-preauth`) and the insurance use case (`nhcx-insurance`) own these. The checks are here, so neither skill need be installed.

| Capability | Why | Look for | Present when (observed) |
| --- | --- | --- | --- |
| `preauth.send`, `preauth.response-reader` | The claim needs an approved or partial pre-auth and its `preAuthRef` (ERR-PYR-CLM-007 otherwise) | a pre-auth leg with `txn_id`, `correlation_id`, `preauth_ref`; a ClaimResponse reader | A pre-auth sent with a stubbed client on `v1/preauth/submit` (workflow 12), then fed `nhcx-package/fhir/C5/C5-received-wf20.json` and `C5-approved-wf21.json` on its correlation id, ends `approved` with `preauth_ref` set |
| `preauth.claim-bundle` | One builder; the claim legs extend it | a Claim bundle builder with `leg` and `flow` arguments | Fed the pin's data, it produces `preauth/request` byte for byte (compared without `factor`); if it is missing, this skill stops rather than write a second builder |
| `preauth.dossier` | Diagnoses, the care team, documents and forms ride the claim too | diagnosis, care team, document and form answer tables per episode | An episode holds ICD-10 diagnoses, a care team member with an HPIN, documents with the plan's codes and answered forms |
| `insurance.lines` | The lines, and `LM100` at the plan's rate | a line table priced from the plan | Lines carry the plan's rate as `unit_price`, integer quantities, and tiers with `parent_code` |

### Host facts

How the discharge is recorded, and whether it carries a mode, a stage, a surgery time and a death time; procedures and surgery times; the discharge summary document; invoice lines for reconciliation.

## The ladder, for this skill

| Stage | What is specific here |
| --- | --- |
| 0 | The tables above. |
| 1 | Confirm the shared page, or write it if this skill runs first on the app. Own rows: B5, D9, D10. |
| 2 | Risks: the claim under the pre-auth's number (ERR-PYR-CLM-007); PMJAY bills the package alone at the whole amount; no claim resubmit on PMJAY, where a decided claim is reprocessed; 151 on PMJAY is PAYR-1321, so 161; a death without `DTM` is PAYR-1096; a package on a LAMA or DAMA claim before or during surgery is PAYR-1362; the consent form at the claim (PAYR-1363) and the guideline forms (PAYR-1365). |
| 3 | The host facts above. |
| 4 | The discharge fields' sources; the Claim bundle's claim-leg source map; `preAuthRef` from the ClaimResponse; the claim answer's destinations. If this skill maps first, every table's home too. |
| 5 | The Claim tab; actions F10 and F11. |
| 6 | The claim parts of 7.7 and 7.8; the foundation modules stage 0 found absent or partial. |
| 7 | Extend the one builder; never write a second. |
| 8 | The rows of 7.7 and 7.8 that name the claim legs, and the pre-auth rows of 7.7 again, since the builder changed. |
| 9 | Two pin comparisons; reader tests on 25, 26, 27 and 291; matrix rows B5, D9, D9 LAMA or DAMA, D9 death and D10; every discharge variant in `references/flow-knowledge.md` section 6; the cross-cutting rows on the claim thread. |
| 10 | Rung 1. Rung 3 walks B5. Rung 4 walks D9 and its variants, and D10. |
| 11 | This skill's section. |

## Rules for these legs

- The claim goes under the pre-auth's claim number, with the payer's `preAuthRef`.
- On the claim, procedures are `completed`, and the discharge scalars, `HDS` (the plan's summary code), `ONS/PSP`, `ONS/DSDE` and `DIS` ride it.
- LAMA or DAMA before or during surgery: one `LM100` item at the plan's rate, no tier, nothing else. After surgery the package stands.
- A death carries `ONS/DTM` and the death forms.
- There is no separate discharge submission on PMJAY; the discharge rides on the claim.
- The discharge summary is always attached, with the documents the ruling deferred to the claim and the consent form again.
- A claim refused at the door offers "Send the claim again" while a send kind remains, else "Ask for a reprocess".

## Done when

- Every gate in this skill's block of `nhcx-build/STATE.md` is closed with evidence.
- The two claim pins pass, and the three pre-auth Claim pins still pass after the extension.
- The compliance points in `core/LADDER.md` hold for F10 and F11.
