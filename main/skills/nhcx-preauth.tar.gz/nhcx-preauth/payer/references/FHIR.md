# FHIR

Every FHIR resource the application builds for NHCX or reads from a hospital's message, in one list. Each row links to its full spec in [../fhir/](../fhir/INDEX.md). Sent profiles are the NRCeS profiles under `https://nrces.in/ndhm/fhir/r4/StructureDefinition/`; received resources are read without checking a profile.

## Envelope

| # | Resource | Direction | What it is | Used by |
|---|---|---|---|---|
| [F1](../fhir/F1-bundle.md) | Bundle | both | The envelope of every message: ids, profiles, entry order and absolute references; what this payer wraps its answers in and how it unwraps a hospital's bundle. | [A3](../apis/A3-preauth-answer.md), [A8](../apis/A8-status-answer.md), [A9](../apis/A9-task-answer.md), [A10](../apis/A10-predetermination-quote.md), [A12](../apis/A12-txn-fhir.md), [A15](../apis/A15-case-exchange.md), [C1](../callbacks/C1-callback-door.md), [C4](../callbacks/C4-preauth-submit.md), [C6](../callbacks/C6-predetermination.md), [C7](../callbacks/C7-task-submit.md), [C8](../callbacks/C8-status-enquiry.md) |

## Eligibility and plan

| # | Resource | Direction | What it is | Used by |
|---|---|---|---|---|
| [F2](../fhir/F2-coverage-eligibility-request.md) | CoverageEligibilityRequest | received | A hospital's eligibility question: purposes, the handles it carries (member id, subscriber id, ABHA, mobile, name), the provider, and the items of an auth-requirements ask. | [C1](../callbacks/C1-callback-door.md) |
| [F3](../fhir/F3-coverage-eligibility-response.md) | CoverageEligibilityResponse | sent | This payer's answer: in force with the wallet as benefit, lapsed with the reason, or no cover; per item for auth-requirements, the package rate and the documents and forms wanted at each stage, in the dialect the hospital reads. | none |
| [F4](../fhir/F4-task-insuranceplan.md) | Task (InsurancePlan request) | received | The hospital's plan request: a Task naming a policy number and the asking provider. | [C1](../callbacks/C1-callback-door.md) |
| [F5](../fhir/F5-insuranceplan.md) | InsurancePlan | sent | The package master this payer publishes: the product, its coverage clauses with benefits and limits, each covered procedure with its rate, documents per leg and its own forms, the policy forms, proof of identity when biometric is required, exclusions and sub-limits; or an empty plan. | none |
| [F6](../fhir/F6-questionnaire.md) | Questionnaire | sent | A form the plan ships, the policy's or a procedure's, in one shape: a title, a description and typed questions, published at /questionnaire/<owner>/<form id> and named Questionnaire. | none |

## Pre-authorisation and claim

| # | Resource | Direction | What it is | Used by |
|---|---|---|---|---|
| [F7](../fhir/F7-questionnaireresponse.md) | QuestionnaireResponse | received | The hospital's answers to the forms, filed beside the case and shown on the desk. | [A15](../apis/A15-case-exchange.md), [C4](../callbacks/C4-preauth-submit.md) |
| [F8](../fhir/F8-claim.md) | Claim | received | The hospital's dossier for a pre-authorisation, a claim or a predetermination: patient handles, hospital, admission, diagnoses, care team, items with modifiers and factors, documents, discharge block, query note, the prior it enhances. | [A10](../apis/A10-predetermination-quote.md), [C1](../callbacks/C1-callback-door.md), [C4](../callbacks/C4-preauth-submit.md), [C6](../callbacks/C6-predetermination.md) |
| [F9](../fhir/F9-claimresponse.md) | ClaimResponse | sent | This payer's acknowledgement and verdict: outcome and claim-level adjudication from the decision, per-item adjudication from the line decisions, totals, the case number as preAuthRef, the remarks in the disposition. | [A3](../apis/A3-preauth-answer.md), [A8](../apis/A8-status-answer.md), [A9](../apis/A9-task-answer.md), [A10](../apis/A10-predetermination-quote.md), [A13](../apis/A13-adjudicate.md), [A15](../apis/A15-case-exchange.md), [C6](../callbacks/C6-predetermination.md) |
| [F10](../fhir/F10-task-claim-actions.md) | Task (claim actions and answers) | both | Received: cancel, reprocess, release, status and payment acknowledgement Tasks. Sent: the completed Task answering them, with the ClaimResponse or the status on its output. | [A8](../apis/A8-status-answer.md), [A9](../apis/A9-task-answer.md), [A12](../apis/A12-txn-fhir.md), [C1](../callbacks/C1-callback-door.md), [C7](../callbacks/C7-task-submit.md), [C8](../callbacks/C8-status-enquiry.md) |

## Queries and payment

| # | Resource | Direction | What it is | Used by |
|---|---|---|---|---|
| [F11](../fhir/F11-communicationrequest.md) | CommunicationRequest | sent | This payer's query: one payload per thing wanted, about the Claim, addressed to the hospital, wrapped in a Task coded poll, on a fresh thread. | [A13](../apis/A13-adjudicate.md), [A15](../apis/A15-case-exchange.md) |
| [F12](../fhir/F12-communication.md) | Communication | received | The hospital's reply: texts, attachments with their document codes, and the references it hangs on. | [C1](../callbacks/C1-callback-door.md) |

## Parties and supporting resources

| # | Resource | Direction | What it is | Used by |
|---|---|---|---|---|
| [F15](../fhir/F15-patient.md) | Patient | both | Read from a hospital's bundle for the handles; written into answers as this payer's member. | [A3](../apis/A3-preauth-answer.md), [A8](../apis/A8-status-answer.md), [A9](../apis/A9-task-answer.md), [A10](../apis/A10-predetermination-quote.md), [C4](../callbacks/C4-preauth-submit.md) |
| [F16](../fhir/F16-practitioner.md) | Practitioner | received | The treating team as declared, kept on the case by HPR id. | [C4](../callbacks/C4-preauth-submit.md) |
| [F17](../fhir/F17-organization.md) | Organization | both | Sent: this payer as the insurer Organization (IRDAI registration, ROHINI id, participant code) and the hospital named back by its HFR id. Received: the hospital's own Organization, read for its HFR id and name. | [A3](../apis/A3-preauth-answer.md), [A8](../apis/A8-status-answer.md), [A9](../apis/A9-task-answer.md), [A10](../apis/A10-predetermination-quote.md), [C4](../callbacks/C4-preauth-submit.md) |
| [F18](../fhir/F18-coverage.md) | Coverage | both | Sent: the enrolment as Coverage with the product, member id, period and class. Received: the policy the hospital quotes. | [A3](../apis/A3-preauth-answer.md), [A8](../apis/A8-status-answer.md), [A9](../apis/A9-task-answer.md), [A10](../apis/A10-predetermination-quote.md), [C4](../callbacks/C4-preauth-submit.md) |
| [F19](../fhir/F19-other-resources.md) | Other resources | received | Procedure, Condition, Encounter and Location as a hospital sends them, read into the case. | [C4](../callbacks/C4-preauth-submit.md) |
