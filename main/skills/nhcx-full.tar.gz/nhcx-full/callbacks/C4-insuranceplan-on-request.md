# C4. Insurance Plan Reply

#### C4E. ENDPOINT
Delivered in-process by [G8. Receive](../gateway/G8-receive.md) for NHCX route `v1/insuranceplan/on_request`, passed to `C1.receive` with `delivery.type` `insurance`. Answers A3.

#### C4D. DESCRIPTION
The payer's package master for the policy, a few seconds after A3 went out. Matched by `x-hcx-correlation_id` against the plan row (D10 `correlation_id`, newest row). Nothing matching answers `unmatched`.

The reply is large (a PMJAY master is some 45 MB encrypted [SANDBOX](../references/PAYERS.md#markers)). The handler reads the decrypted bundle once, writes `response_json` once on the plan row, never logs or pretty-prints it, and parses the benefits in a single pass; the inbound path that gets it this far is described in [G8. Receive](../gateway/G8-receive.md) and [G6. Encryption](../gateway/G6-encryption.md).

Only a plan still `fetching` takes it; a settled plan answers `ignored`. The payer redelivers the same master several times on one thread [SANDBOX](../references/PAYERS.md#markers). A plan on record as a failed send (`error`) is reopened and the reply applied.

A bundle with no InsurancePlan at all (only the payer's Organization) is the payer saying it has nothing filed under this policy [SANDBOX](../references/PAYERS.md#markers). It is settled as an empty plan with a message, not rejected, so the plan does not sit in `fetching`. Polling looks only for replies that carry an InsurancePlan, so this outcome is reached through the callback only.

#### C4Q. REQUEST
`fhir` is an F1 Bundle carrying one F5 InsurancePlan, usually beside the payer's F17 Organization and its F6 Questionnaires.

A reply that carries no InsurancePlan is settled as `empty`. A refusal arrives as a `ProtocolResponse` (for example PAYR-1008 or PAYR-1401 [PAYER](../references/PAYERS.md#markers)).

#### C4P. PSEUDOCODE

```
C4(envelope, corr):
    row = newest D10 where correlation_id == corr
    if none: return "unmatched"
    if row.status != "fetching" and not failed_send(row):
        return "ignored"
    body = payload(envelope)
    if body.type == "ProtocolResponse":
        write D10: status = "error", error_message = rejection(body)
        return "settled"
    revive(D10, row, "fetching")
    try:
        parsed = read_plan(body)       # A3S "How the reply is read"
    except no InsurancePlan in body:
        apply_plan(row, no benefits, no values, body)                  # status "empty"
        write D10: error_message = "The payer reply carries no InsurancePlan. " +
                                   "The payer has no package master filed under this policy."
        return "settled"
    apply_plan(row, parsed, body)
    return "settled"

read_plan(body):
    plan = first InsurancePlan                       # none -> the except branch above
    values = {plan_identifier (identifier[0].value, else id), plan_title (name),
              plan_type (type[0] display), sum_insured (first plan[].generalCost[].cost.value),
              policy_documents (requirements on the InsurancePlan itself and the forms pointed
              at from coverage[].extension: a form pointed at from coverage is a policy form,
              asked of every case, never one of the packages under that coverage)}
    benefits = packages from plan[].specificCost[].benefit[] (package master shape)
               merged on the pair (category code, package code) with coverage[].benefit[]
               (indemnity shape), specificCost winning, one row per speciality a code is
               listed under (F5); each with category, code, display, kind, rate,
               currency, cost_type, conditions, extras (tiers), supporting_info (a procedure's
               own forms are pointed at from its plan.specificCost benefit)
    forms = each Questionnaire once per url, with its D11 stage (pre or post, read from the
            payer's word else its title; pre when neither says)
    return {values, benefits, forms}

apply_plan(row, parsed, body):
    in one transaction:
        write D10: parsed.values, status = "ready" if benefits else "empty",
                   fetched_at = now, error_message = null, response_json = body
        delete D11 and D12 rows of this plan
        insert D11 per benefit with seq 1..n
        insert D12 per form
        if status == "ready":
            D32 rows whose code's part before "@" equals that of the case's payer_id,
                with plan_fetched_at null: set plan_fetched_at = now   // "In network", S17
```

#### C4S. RESPONSE
`settled`, `unmatched`, or `ignored` for a plan no longer `fetching`. No InsurancePlan in the bundle is not `rejected`; only a missing `fhir` is.

State changes:

| Table | Change |
|---|---|
| D10 claim_plan | `status` `ready` (at least one package), `empty` (none, including the no-InsurancePlan case, which also sets `error_message`), or `error` with `<code>: <message>`; plan identifier, title, type, sum insured, policy documents; `fetched_at`; `response_json` |
| D11 claim_plan_benefit | replaced: one row per (speciality, package) |
| D12 claim_plan_form | replaced: one row per Questionnaire |
| D32 participant | on a `ready` plan, the case's payer gets `plan_fetched_at` = now when it had none (the payer is "In network" from then on) |

#### C4U. USED BY
- Screens: [S7. Insurance Plan](../screens/S7-insurance-plan.md)
- APIs: [A3. Insurance Plan Request](../apis/A3-insurance-plan-request.md), [A10. Transaction Related](../apis/A10-txn-related.md), [A12. Transaction FHIR](../apis/A12-txn-fhir.md), [A17. Claim State](../apis/A17-claim-state.md)
- Callbacks: [C1. Callback Door](C1-callback-door.md), [C3. Authorisation Requirements Ruling](C3-auth-requirements-on-check.md)
- Database: [D10. claim_plan](../database/D10-claim-plan.md), [D32. participant](../database/D32-participant.md)
- Gateway: [G8. Receive](../gateway/G8-receive.md)
- Tests: [T1. Test Configuration](../tests/T1-test-configuration.md), [T4. IRDAI Insurance Plan and Authorisation Requirements](../tests/T4-irdai-plan-and-auth-requirements.md), [T13. PMJAY Eligibility, Package Master and Ruling](../tests/T13-pmjay-eligibility-and-package-master.md)
