# D16. claim_line

#### D16T. TABLE
One row is one line the pre-authorisation quotes from the payer's package master: a procedure, an implant or a ward / ICU stratification tier. Primary key `id`. Parent table: `claim` (D9).

#### D16D. DESCRIPTION
The lines are the procedure set of the case. They are chosen on Line Items (S8) only once the payer's insurance plan (D10) is `ready`; the price always comes from the plan (D11), never from the form.

**Created.** "Add" on S8 inserts one row:

- `Procedure` or `Implant`: the code must be a D11 benefit of that `kind` **under the posted speciality** in the claim's plan (the pair (`category_code`, `code`) names the row, since a code is listed under several specialities [PAYER](../references/PAYERS.md#markers)). `display`, `category_code`, `category_display`, `benefit_id` and `unit_price` (the benefit's `rate`, 0 when it has none) are copied from it.
- `Stratification`: the tier is resolved through the procedure it is quoted with (`parent_code`), because different procedures price the same ward differently [PAYER](../references/PAYERS.md#markers). The tier must appear in that procedure's `extras` with type `Stratification`; its `label` becomes `display` and its `rate` becomes `unit_price`. The category is the parent procedure's.
- `seq` is the claim's highest `seq` plus 1, `quantity` is 1 and `amount` is `unit_price` rounded to 2 places.
- Adding a code already on the claim under the same kind: refused ("<code> is already on this preauth.") unless the package is **cyclic**, one the payer bills per cycle or session (the plan's conditions mark it, or the adapter lists it, [PAYERS.md](../references/PAYERS.md)) [PAYER](../references/PAYERS.md#markers). A cyclic package gets a new row with `cycle` = the highest cycle of that code on the claim plus 1. PMJAY answers an enhancement that raises a cycle's quantity with PAYR-1274 and wants a new item per cycle instead [PAYER](../references/PAYERS.md#markers); one row per cycle is what makes the enhancement a new item on the wire.

**Updated.** "Save quantities" on S8 rewrites every line in one transaction:

- `quantity` must be a whole number above 0, and stays 1 on a cyclic line (another cycle is another line).
- `unit_price` may be changed only where the price is **open**: the plan names no rate, or names 0 and offers no `Stratification` extra for the package. A rate of 0 with ward or ICU tiers is a fixed price made of its tiers, not an open one. Anywhere else the plan's rate stands. A negative price is refused.
- `amount` is always recomputed as `unit_price * quantity`, rounded to 2 places.

**Deleted.** "Remove" on S8 deletes one row. Rows also go when the claim is deleted (cascade) or when the whole transactional store is cleared.

**How the lines are read.**

- `lines_total` (the sum of `amount`) is the pre-authorisation's requested amount (D18 `requested_amount`, D19 `requested_amount`) and the claim's `preauth_total` for a package case.
- The first `Procedure` line names the claim's `package_code` and `package_name` when the pre-auth draft (S4) is saved for a package case.
- On the wire a `Stratification` line is not an item of its own: it rides as a `modifier` on its parent procedure's `Claim.item`, and its rate is inside that item's `net`. A tier with no `parent_code` (quoted before the column existed) falls back to the first procedure whose plan costs offer it, then to the first procedure.
- Enhancement: lines whose (code, cycle) is not in the last pre-authorisation bundle sent (D18 `request_json`, read back by `productOrService` code and the item's cycle sequence) are the enhancement lines, once D18 is `approved` or `partial`. A second cycle of a code already approved is therefore an enhancement line, as PMJAY requires [PAYER](../references/PAYERS.md#markers).
- The claim leg quotes these same lines, except that a LAMA or DAMA discharge before or during surgery (D20) replaces them all with the single procedure `LM100` [PAYER](../references/PAYERS.md#markers). That substitution is computed at send time and is not stored here.
- The auth-requirements ruling (D13) is stale when the set of non-`Stratification` codes here differs from the codes ruled on (D14).

There is no status column.

#### D16C. COLUMNS
| Column | Type | Null / default | Meaning |
|---|---|---|---|
| id | INTEGER | primary key | Row id |
| claim_id | INTEGER | NOT NULL | The claim (D9) the line is quoted on |
| seq | INTEGER | NOT NULL, default 1 | Order of addition within the claim |
| kind | TEXT | NOT NULL | `Procedure`, `Implant` or `Stratification` (shown as "Ward / ICU tier") |
| code | TEXT | NOT NULL | Package, implant or tier code from the payer's plan |
| display | TEXT | null | Name from the plan (tier: its label) |
| category_code | TEXT | null | Speciality code, sent as `Claim.item.category` |
| category_display | TEXT | null | Speciality name |
| unit_price | REAL | NOT NULL, default 0 | The plan's rate; hospital price only where the plan prices it at nothing |
| quantity | REAL | NOT NULL, default 1 | Whole number of times done or implants used |
| amount | REAL | NOT NULL, default 0 | `unit_price * quantity`, recomputed on every save |
| parent_code | TEXT | null | For `Stratification` only: the procedure code the tier was quoted through. Null for the other kinds. Added by migration |
| benefit_id | INTEGER | null | The D11 row the line was picked from (the (speciality, code) pair under the claim's plan), so the detail, tiers, conditions and documents shown for the line are the ones of the speciality it was quoted under. Added by migration |
| cycle | INTEGER | NOT NULL, default 1 | Cycle or session number for a cyclic package; 1 for every other line. Added by migration |

#### D16K. KEYS AND INDEXES
- Primary key `id` (integer).
- Foreign key `claim_id` references `claim (id)` (D9), `ON DELETE CASCADE`.
- `benefit_id` references `claim_plan_benefit (id)` (D11), `ON DELETE SET NULL`.
- Unique index `ux_claim_line` on `(claim_id, kind, code, cycle)`: a code appears once per kind and cycle on a claim.

#### D16U. USED BY
- Screens: [S11. Claim Submission](../screens/S11-claim-submission.md)
- APIs: [A17. Claim State](../apis/A17-claim-state.md)
- FHIR: [F8. Claim](../fhir/F8-claim.md), [F19. Other bundle resources](../fhir/F19-other-resources.md)
- Database: [D9. claim](D9-claim.md), [D11. claim_plan_benefit](D11-claim-plan-benefit.md), [D15. claim_auth_requirement](D15-claim-auth-requirement.md), [D18. claim_preauth](D18-claim-preauth.md)
