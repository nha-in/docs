# FHIR

Every FHIR resource the application builds for NHCX or reads back, in one list. Each row links to its full spec in [../fhir/](../fhir/INDEX.md). Sent profiles are the NRCeS profiles under `https://nrces.in/ndhm/fhir/r4/StructureDefinition/`; received resources are read without checking a profile.

## Envelope

| # | Resource | Direction | What it is | Used by |
|---|---|---|---|---|
| [F1](../fhir/F1-bundle.md) | Bundle | both | The envelope of every NHCX message: bundle id, profile, anchor entry first and a fixed entry order, absolute URLs under `https://nhcx.abdm.gov.in` as references. | [A7](../apis/A7-communication-on-request.md), [A12](../apis/A12-txn-fhir.md), [C1](../callbacks/C1-callback-door.md), [C9](../callbacks/C9-communication-request.md) |

## Eligibility and plan

| # | Resource | Direction | What it is | Used by |
|---|---|---|---|---|
| [F3](../fhir/F3-coverage-eligibility-response.md) | CoverageEligibilityResponse | received | The payer's verdict (in force, wallet, pre-auth needed) or its ruling on each quoted item with the documents and forms required. | none |

## Pre-authorisation and claim

| # | Resource | Direction | What it is | Used by |
|---|---|---|---|---|
| [F8](../fhir/F8-claim.md) | Claim | sent | One document for every leg: pre-auth, enhancement, predetermination, claim and query answers; items, diagnoses, care team, supportingInfo documents, total. | [A7](../apis/A7-communication-on-request.md), [A17](../apis/A17-claim-state.md) |
| [F10](../fhir/F10-task-claim-actions.md) | Task (claim actions) | sent and received | A follow-up on a case: cancel, status, reprocess or release, and the payer's Task answers to them. | [A7](../apis/A7-communication-on-request.md) |

## Payer communication and payment

| # | Resource | Direction | What it is | Used by |
|---|---|---|---|---|
| [F11](../fhir/F11-communicationrequest.md) | CommunicationRequest | received | A payer query or notification on a thread the payer opens, usually wrapped by a Task; classified as query or notification. | [A7](../apis/A7-communication-on-request.md), [C9](../callbacks/C9-communication-request.md) |
| [F12](../fhir/F12-communication.md) | Communication | sent (and received as a note) | The reply to a query (text and files, with the case resources) or the acknowledgement of a notification; a bare Communication from the payer is filed as a note. | [A7](../apis/A7-communication-on-request.md) |

## Parties and supporting resources

| # | Resource | Direction | What it is | Used by |
|---|---|---|---|---|
| [F15](../fhir/F15-patient.md) | Patient | sent | The beneficiary: member id, ABHA and scheme identifiers, name, gender, birth date, phone from the linked patient, falling back to the policy. | [A7](../apis/A7-communication-on-request.md), [C9](../callbacks/C9-communication-request.md) |
| [F16](../fhir/F16-practitioner.md) | Practitioner and PractitionerRole | sent | The care team doctors (HPR id, degree coding) on claim-side bundles, and the fixed PractitionerRole that enters an eligibility check. | [A7](../apis/A7-communication-on-request.md), [C9](../callbacks/C9-communication-request.md) |
| [F17](../fhir/F17-organization.md) | Organization | sent and received | The provider (HFR id) and the payer (participant code). | [A7](../apis/A7-communication-on-request.md), [C9](../callbacks/C9-communication-request.md) |
| [F18](../fhir/F18-coverage.md) | Coverage | sent | The policy: policy code and member id, `NONE` for a discovery, plus the payer's Coverage read back (plan name, period, relationship). | [A7](../apis/A7-communication-on-request.md), [C9](../callbacks/C9-communication-request.md) |
